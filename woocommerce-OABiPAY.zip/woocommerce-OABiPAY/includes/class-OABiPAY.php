<?php

class OABiPAY_DAO {

    public function __construct() {
	}

	public function run() {
        $plugin = new OABiPAY();
        $plugin->pymnt_install();
	}

    function pymnt_install() {
        global $wpdb;
        global $db_version;
        $installed_ver = get_option("oabipay_db_v", "");
        if ( $installed_ver != $db_version ) {
            $table_name = $wpdb->prefix . 'oabipaypymnt';
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                id bitint(20) NOT NULL AUTO_INCREMENT,
                tranid bitint(20) NOT NULL,
                paymentid bitint(20) NOT NULL,
                authcode varchar(25) NULL,
                postdate varchar(25) NULL,
                trackid varchar(25) NOT NULL,
                resstatus varchar(25) NOT NULL,
                descrip varchar(100) NULL,
                trantime datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;";
            require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
            dbDelta( $sql );
            add_option( 'oabipay_db_v', $db_version );
        }
    }

    function pymnt_select_data($tranid) {
        global $wpdb;	
        $welcome_name = 'Mr. WordPress';
        $welcome_text = 'Congratulations, you just completed the installation!';
        $table_name = $wpdb->prefix . 'liveshoutbox';
        $wpdb->insert( 
            $table_name, 
            array( 
                'time' => current_time( 'mysql' ), 
                'name' => $welcome_name, 
                'text' => $welcome_text, 
            ) 
        );
    }
    
    
}