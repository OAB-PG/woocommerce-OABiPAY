<?php
/**
 * Class WC_Gateway_OAB_Request file.
 *
 * @package WooCommerce\Gateways
 */
use Automattic\WooCommerce\Utilities\NumberUtil;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Gateway_OAB_Request {

	protected $callbackUrl;

	public function __construct() {
		$this->callbackUrl = WC()->api_request_url( 'WC_Gateway_OAB_CallBack' );
	}

	protected function limit_length( $string, $limit = 200 ) {
		$str_limit = $limit - 3;
		if ( function_exists( 'mb_strimwidth' ) ) {
			if ( mb_strlen( $string ) > $limit ) {
				$string = mb_strimwidth( $string, 0, $str_limit ) . '...';
			}
		} else {
			if ( strlen( $string ) > $limit ) {
				$string = substr( $string, 0, $str_limit ) . '...';
			}
		}
		return $string;
	}

	public function get_payment_args( $order , $id, $password, $webAddr, $termResKey) {
		$currency	= "512";
		$language	= "ENG";
		try {
			$all_items_name = $this->get_order_item_names( $order );
			include_once dirname( __FILE__ ) . '/iPayOabPipe.php';
			include_once dirname( __FILE__ ) . '/SecureStoreOab.php';
			error_log ('id :: '.$id);
			error_log (', webAddr :: '.$webAddr);

			$myObj = new iPayOabPipe();
			$myObj->setCurrency(trim($currency));
			$myObj->setLanguage(trim($language));
			$myObj->setResponseURL(trim($this->callbackUrl));
			$myObj->setErrorURL(trim($this->callbackUrl));

			$myObj->setAction('1');
			$myObj->setAmt($order->get_total());
			$myObj->setTrackId($order->get_id());
			$myObj->setUdf1(preg_replace('/[^A-Za-z0-9\-]/', 'SPL',$this->limit_length( utf8_encode($order->get_billing_first_name()), 60)));
			$myObj->setUdf2((preg_replace('/[^A-Za-z0-9\-]/', 'SPL',$this->limit_length( $order->get_billing_phone(), 40 ))));
			
			$myObj->setUdf3((preg_replace('/[^A-Za-z0-9\-]/', 'SPL',$this->limit_length( utf8_encode($all_items_name), 40 ))));
			$myObj->setUdf4((preg_replace('/[^A-Za-z0-9\-]/', 'SPL',$this->limit_length( utf8_encode($order->get_billing_city().''.$order->get_billing_country().''.$order->get_billing_state()), 100 ))));
			$myObj->setUdf5(preg_replace('/[^A-Za-z0-9\-]/', 'SPL',$this->limit_length( $order->get_billing_email(), 40)));
			$result = $myObj->performPaymentInitWooComHTTP($id, $password, $webAddr, $termResKey);
			if(trim($result) == 0) {
				$url=$myObj->getWebAddress();
			} else {
				$url = $myObj->getErrorURL()."?ErrorText=".$myObj->getError();
			}
			error_log('$url :: '.$url);
		} catch(Exception $e) {
			error_log('Error File  :: '.$e->getFile());
			error_log('Error Code  :: '.$e->getCode());
			throw $e;
		}
		return $url;
	}

	protected function get_order_item_names( $order ) {
		$item_names = array();
		foreach ( $order->get_items() as $item ) {
			$item_name = $item->get_name();
			$item_meta = wp_strip_all_tags(
				wc_display_item_meta(
					$item,
					array(
						'before'    => '',
						'separator' => ', ',
						'after'     => '',
						'echo'      => false,
						'autop'     => false,
					)
				)
			);
			if ( $item_meta ) {
				$item_name .= '' . $item_meta . '';
			}
		}
		return $item_name;
	}

	protected function get_order_item_name($item ) {
		$item_name = $item->get_name();
		$item_meta = wp_strip_all_tags(
			wc_display_item_meta(
				$item,
				array(
					'before'    => '',
					'separator' => ', ',
					'after'     => '',
					'echo'      => false,
					'autop'     => false,
				)
			)
		);
		if ( $item_meta ) {
			$item_name .=  $item_meta ;
		}
		return $item_name;
	}

}
