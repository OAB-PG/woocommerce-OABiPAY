<?php
/**
 * Class WC_Gateway_OAB_CallBack file.
 *
 * @package WooCommerce\Gateways
 */

use Automattic\Jetpack\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Gateway_OAB_CallBack {

	protected $logger;

	public function __construct() {
		$this->logger = wc_get_logger();
		$this->logger->info('Callback handler initialized.', ['source' => 'oabipay']);
		add_action( 'woocommerce_api_wc_gateway_oab_callback', array( $this, 'check_response' ) );
	}

	protected function validate_transaction( $transaction ) {
		// Placeholder for transaction validation logic
		return false;
	}

	public function check_response() {
		if ( empty($_POST['trandata']) ) {
			$this->logger->error('Callback: Missing trandata in POST.', ['source' => 'oabipay']);
			wp_die( '-1', 400 );
		}

		$tranData = sanitize_text_field( $_POST['trandata'] );
		$this->logger->info('Callback: Received trandata.', ['source' => 'oabipay', 'trandata' => $tranData]);

		try {
			include_once dirname( __FILE__ ) . '/iPayOabPipe.php';
			include_once dirname( __FILE__ ) . '/SecureStoreOab.php';

			$settings = get_option('woocommerce_oabipay_gateway_settings');
			$termResKey = !empty($settings['termResKey']) ? $settings['termResKey'] : '';

			$this->logger->info('Callback: Loaded termResKey.', ['source' => 'oabipay', 'termResKey' => substr($termResKey, 0, 4) . '...']);

			$myObj = new iPayOabPipe();
			$result = $myObj->parsePaymentResponse($tranData, $termResKey);
			$resultCode = $myObj->getresult();
			$order_id = $myObj->gettrackId();

			$this->logger->info("Callback: Payment parsed. Result = $result, Code = $resultCode, Order ID = $order_id", ['source' => 'oabipay']);

			$order = wc_get_order($order_id);
			if ( ! $order ) {
				$this->logger->error('Callback: Invalid Order ID.', ['source' => 'oabipay', 'order_id' => $order_id]);
				wp_die( '-1', 400 );
			}

			if ( $result == 0 && $resultCode === "CAPTURED" ) {
				$order->payment_complete();
				wc_reduce_stock_levels($order_id);
				WC()->cart->empty_cart();
				$this->logger->info("Callback: Payment successful. Redirecting to thank you page.", ['source' => 'oabipay', 'order_id' => $order_id]);
				wp_redirect($this->get_return_url($order));
				exit;
			} elseif ( $result == 0 && $resultCode === "IPAY0100048 - Cancelled" ) {
				$order->update_status('cancelled', 'OAB iPay payment was cancelled by user.');
				$this->logger->warning("Callback: Payment cancelled by user.", ['source' => 'oabipay', 'order_id' => $order_id]);
				wp_redirect($this->get_error_page_url());
				exit;
			} else {
				$order->update_status('failed', 'OAB iPay payment failed or declined.');
				$this->logger->error("Callback: Payment failed or declined.", ['source' => 'oabipay', 'order_id' => $order_id, 'result_code' => $resultCode]);
				wp_redirect($this->get_error_page_url());
				exit;
			}
		} catch ( Exception $e ) {
			$this->logger->error("Callback Exception: " . $e->getMessage(), [
				'source' => 'oabipay',
				'file' => $e->getFile(),
				'line' => $e->getLine(),
				'code' => $e->getCode()
			]);
			wp_die( 'Callback processing error.', 500 );
		}
	}

	public function get_return_url( $order = null ) {
		if ( $order ) {
			$return_url = $order->get_checkout_order_received_url();
		} else {
			$return_url = wc_get_endpoint_url( 'order-received', '', wc_get_checkout_url() );
		}
		return apply_filters( 'woocommerce_get_return_url', $return_url, $order );
	}

	private function pymnt_save_data( $tranid, $paymentid, $authcode, $postdate, $trackid, $resstatus, $descrip ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'oabipaypymnt';

		try {
			$wpdb->insert(
				$table_name,
				[
					'tranid'     => $tranid,
					'paymentid'  => $paymentid,
					'authcode'   => $authcode,
					'postdate'   => $postdate,
					'trackid'    => $trackid,
					'resstatus'  => $resstatus,
					'descrip'    => $descrip,
					'trantime'   => current_time('mysql'),
				]
			);
			$this->logger->info('Callback: Payment data inserted.', ['source' => 'oabipay', 'trackid' => $trackid]);
		} catch ( Exception $e ) {
			$this->logger->error("Callback DB Exception: " . $e->getMessage(), ['source' => 'oabipay']);
		}
	}

	protected function get_error_page_url() {
		$error_page_id = get_option('wc_error_page_id');
		if ($error_page_id) {
			return get_permalink($error_page_id);
		}
		return wc_get_checkout_url();
	}
}
