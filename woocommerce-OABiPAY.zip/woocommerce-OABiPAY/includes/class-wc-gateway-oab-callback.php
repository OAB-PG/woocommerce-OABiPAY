<?php
/**
 * Class WC_Gateway_OAB_CallBack file.
 *
 * @package WooCommerce\Gateways
 */

use Automattic\Jetpack\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class WC_Gateway_OAB_CallBack {

	public function __construct() {
		add_action( 'woocommerce_thankyou_oab', array( $this, 'check_response' ) );
		
	}

	protected function validate_transaction( $transaction ) {
		$transaction_results = false;


		// do the validation for transaction already exits
		return $transaction_results;
	}

	public function check_response($tranData, $termResKey) {
		error_log('Write trandata check_response '.$_POST['trandata']);
		try {
			include_once dirname( __FILE__ ) . '/iPayOabPipe.php';
			include_once dirname( __FILE__ ) . '/SecureStoreOab.php';
			$myObj = new iPayOabPipe();
			$result = $myObj->parsePaymentResponse($tranData, $termResKey);
			error_log('Write result check_response '.$result);
			error_log('Write result Response ::  '.$myObj->getresult());
			$order_id = $myObj->gettrackId();
			$order = wc_get_order( $order_id );
			if($result == 0 && $myObj->getresult() == "CAPTURED"){
				//pymnt_save_data($myObj->gettransId(), $myObj->getpaymentId(), $myObj->getauth(), $myObj->getDate(), $myObj->getref(), $myObj->getresult(), 'Success Transaction');
				error_log('Write order_id check_response '.$order_id);
				error_log('Write order -> getid check_response '.$order->get_id());
				wc_reduce_stock_levels( $order_id );
				WC()->cart->empty_cart();
				error_log('Write $tranData '.$tranData);
				$url = $this->get_return_url( $order );
				wp_redirect($url);
				exit;
				//return array(
				//	'result' 	=> 'success',
				//	'order_id'	=> $order_id,
				//	'redirect'	=> $url
				//);
			}else{
				error_log('Write $$url '.$url);
				return array(
					'result' 	=> 'failure',
					'order_id'  => $order_id
				);
		
			}
		} catch(Exception $e) {
			echo 'Message: ' .$e->getFile();
		  	echo 'Message1 : ' .$e->getCode();
			return array(
				'result' 	=> 'failure',
				'order_id'  => $order_id
			);
		}
	}

	public function get_return_url( $order = null ) {
		if ( $order ) {
			$return_url = $order->get_checkout_order_received_url();
		} else {
			$return_url = wc_get_endpoint_url( 'order-received', '', wc_get_checkout_url() );
		}
		return apply_filters( 'woocommerce_get_return_url', $return_url, $order );
	}

	function pymnt_save_data($tranid, $paymentid, $authcode, $postdate, $trackid, $resstatus, $descrip) {
        global $wpdb;	
        $table_name = $wpdb->prefix . 'oabipaypymnt';
		try {
        	//$wpdb->insert( 
            //	$table_name, 
            //	array( 
            //    	'tranid' => $tranid, 
            //    	'paymentid' => $paymentid, 
            //    	'authcode' => $authcode, 
            //    	'postdate' => $postdate, 
            //   	'trackid' => $trackid, 
            //    	'resstatus' => $resstatus, 
            //    	'descrip' => $descrip, 
            //    	'trantime' => current_time( 'mysql' )
            //	) 
        	//);
		} catch(Exception $e) {
			echo 'Oab iPay Dao Exception : ' .$e->getFile();
		  	echo 'Oab iPay Dao Exception Code : ' .$e->getCode();
		}
    }

}
