<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_Gateway_OABiPAY extends WC_Payment_Gateway {

    public $enabled;
    public $oabTermtitle;
    public $oabTermdescription;
    public $oabTerminstructions;
    public $termName;
    public $tranType;
    public $tranportalId;
    public $termPassword;
    public $termResKey;
    public $instructions;

    public function __construct() {
        $logger = wc_get_logger();
        $logger->info('Initializing OABiPAY Gateway...', ['source' => 'oabipay']);

        $this->id = 'oabipay_gateway';
        $this->icon = apply_filters('woocommerce_oabipay_icon', '');
        $this->has_fields = true;
        $this->order_button_text = __('Pay via Oman Arab Bank', 'wc-oabipay');
        $this->method_title = __('Oman Arab Bank Payment Gateway', 'wc-oabipay');
        $this->method_description = __('Allows payments through <strong>Oman Arab Bank</strong> Payment Gateway.', 'wc-oabipay');

        $this->init_form_fields();
        $this->init_settings();

        foreach ([
            'enabled', 'oabTermtitle', 'oabTermdescription', 'oabTerminstructions',
            'termName', 'tranType', 'tranportalId', 'termPassword', 'termResKey'
        ] as $option) {
            $this->$option = $this->get_option($option);
            $log_value = in_array($option, ['termPassword', 'termResKey']) ? '********' : $this->$option;
            $logger->info("Loaded setting: $option = $log_value", ['source' => 'oabipay']);
        }

        $this->title = $this->oabTermtitle ?: __('OAB iPay', 'wc-oabipay');
        $this->instructions = $this->oabTerminstructions;

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title' => __('Enable/Disable', 'wc-oabipay'),
                'type' => 'checkbox',
                'label' => __('Enable <strong>Oman Arab Bank</strong> Payment Gateway', 'wc-oabipay'),
                'default' => 'yes'
            ],
            'oabTermtitle' => [
                'title' => __('Title', 'wc-oabipay'),
                'type' => 'text',
                'description' => __('Displayed title for OABiPAY.', 'wc-oabipay'),
                'default' => __('OAB iPAY', 'wc-oabipay'),
                'desc_tip' => true,
            ],
            'oabTermdescription' => [
                'title' => __('Description', 'wc-oabipay'),
                'type' => 'textarea',
                'description' => __('Displayed description during checkout.', 'wc-oabipay'),
                'default' => __('Pay securely using <strong>Oman Arab Bank</strong> Payment Gateway.', 'wc-oabipay'),
                'desc_tip' => true,
            ],
            'oabTerminstructions' => [
                'title' => __('Instructions', 'wc-oabipay'),
                'type' => 'textarea',
                'description' => __('Instructions shown on the thank you page and emails.', 'wc-oabipay'),
                'default' => '',
                'desc_tip' => true,
            ],
            'termName' => [
                'title' => __('Terminal Name', 'wc-oabipay'),
                'type' => 'text',
                'description' => __('Terminal name assigned to your merchant account.', 'wc-oabipay'),
                'default' => '',
                'desc_tip' => true,
            ],
            'tranType' => [
                'title' => __('Environment', 'wc-oabipay'),
                'type' => 'select',
                'description' => __('Choose sandbox or production environment.', 'wc-oabipay'),
                'default' => '1',
                'options' => [
                    '1' => __('Sandbox', 'wc-oabipay'),
                    '2' => __('Production', 'wc-oabipay'),
                ],
                'desc_tip' => true,
            ],
            'tranportalId' => [
                'title' => __('Tranportal ID', 'wc-oabipay'),
                'type' => 'text',
                'description' => __('Provided by OABiPAY.', 'wc-oabipay'),
                'default' => '',
                'desc_tip' => true,
            ],
            'termPassword' => [
                'title' => __('Terminal Password', 'wc-oabipay'),
                'type' => 'password',
                'description' => __('Secure terminal password from OABiPAY.', 'wc-oabipay'),
                'default' => '',
                'desc_tip' => true,
            ],
            'termResKey' => [
                'title' => __('Resource Key', 'wc-oabipay'),
                'type' => 'password',
                'description' => __('Decryption key for transaction responses.', 'wc-oabipay'),
                'default' => '',
                'desc_tip' => true,
            ],
        ];
    }

    public function is_available() {
        $logger = wc_get_logger();
        $logger->info('Checking availability of OABiPAY Gateway. Enabled: ' . $this->enabled, ['source' => 'oabipay']);
        return $this->enabled === 'yes';
    }

    public function payment_fields() {
        wc_get_logger()->info('Rendering payment_fields for OABiPAY.', ['source' => 'oabipay']);
        echo '<p>' . wp_kses_post( __('Your transaction is protected with <strong>Oman Arab Bank</strong>\'s secure gateway.', 'wc-oabipay') ) . '</p>';
    }

    public function process_payment($order_id) {
        $logger = wc_get_logger();
        $logger->info("Processing payment for Order ID: $order_id", ['source' => 'oabipay']);

        $order = wc_get_order($order_id);
        $order->update_status('pending', __('Awaiting payment via Oman Arab Bank.', 'wc-oabipay'));

        include_once dirname(__FILE__) . '/class-wc-gateway-oab-request.php';

        $request = new WC_Gateway_OAB_Request();
        $tranType = $this->tranType;

        $webAddr = $tranType == '1'
            ? 'https://certpayments.oabipay.com/trxns'
            : 'https://securepayments.oabipay.com/trxns';

        $url = $request->get_payment_args(
            $order,
            $this->tranportalId,
            $this->termPassword,
            $webAddr,
            $this->termResKey
        );

        $logger->info("Redirecting to: $url", ['source' => 'oabipay']);

        return [
            'result' => 'success',
            'redirect' => $url
        ];
    }

    public function thankyou_page() {
        if ($this->instructions) {
            echo wpautop(wptexturize($this->instructions));
        }
    }

    public function email_instructions($order, $sent_to_admin, $plain_text = false) {
        if ($this->instructions && !$sent_to_admin && $this->id === $order->get_payment_method() && $order->has_status('on-hold')) {
            echo wpautop(wptexturize($this->instructions)) . PHP_EOL;
        }
    }
}
