=== WooCommerce OABiPAY Gateway ===
Contributors: sundareshkumar
Tags: woocommerce, payment gateway, oabipay, oman arab bank, secure payment
Requires at least: 6.0
Tested up to: 6.8.1
Requires PHP: 8.0
Requires WooCommerce at least: 8.0
Tested WooCommerce up to: 9.9.3
Stable tag: 1.0.1
License: Proprietary - Oman Arab Bank
License URI: https://www.oman-arabbank.com/

== Description ==

OABiPAY Gateway is a WooCommerce payment gateway plugin designed specifically for Oman Arab Bank merchants. This plugin allows customers to pay securely using the OAB iPay platform.

Features:
* Secure integration with OAB iPay.
* Configurable terminal credentials (ID, password, resource key).
* Auto-redirect after transaction success or failure.
* Custom failure page template for better UX.
* Admin settings page for configuration.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/woocommerce-oabipay/` directory or use the **Add Plugin** option.
2. Activate the plugin through the ‘Plugins’ menu in WordPress.
3. Go to **WooCommerce > Settings > Payments**.
4. Enable **OAB iPay Gateway** and click **Manage** to configure the plugin.

== Frequently Asked Questions ==

= What is required to use this plugin? =
You must have an active merchant account with Oman Arab Bank and valid credentials (Terminal ID, Password, Resource Key).

= Does this plugin support subscription payments? =
No, recurring or subscription payments are not supported in the current version.

== Changelog ==

= 1.0.1 =
* Initial stable release.
* PHP 8.2 compatibility.
* WordPress 6.8.1 and WooCommerce 9.9.3 support.

== Upgrade Notice ==

= 1.0.1 =
This is the first stable version. Upgrade only if you’re running WordPress 6.0+ and WooCommerce 8.0+.
