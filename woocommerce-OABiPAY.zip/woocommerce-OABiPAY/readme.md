=== WooCommerce OABiPAY Gateway ===

 - Contributors: skyverge, beka.rice
 - Tags: woocommerce, payment gateway, gateway, manual payment
 - Requires at least: 3.8
 - Tested up to: 4.3
 - Requires WooCommerce at least: 2.1
 - Tested WooCommerce up to: 2.4
 - Stable Tag: 1.0.1
 - Licence Thiru Softwares & Systems
