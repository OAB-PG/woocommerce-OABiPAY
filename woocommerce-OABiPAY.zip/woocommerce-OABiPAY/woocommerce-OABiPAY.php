<?php
/**
 * Plugin Name: WooCommerce OABiPAY
 * Author: SundareshKumar KV
 * Version: 0.0.1
 * Text Domain: wc-oabipay
 * Description: WC-Gateway-OABiPAY will allows Woocomerece Customers to integrate with OABiPAY Payment Gateway in to their WooCommerce Application.
 *
 * @package   WC-Gateway-OABiPAY
 * @author    SundareshKumar KV
 * @category  Admin
 * @copyright OAB iPAY
 *
 * This OABiPAY gateway will allows Woocomerece Customers to integrate with OABiPAY Payment Gateway in to their WooCommerce Application.
 */
 
defined( 'ABSPATH' ) or exit;
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}

function wc_oabipay_add_to_gateways( $gateways ) {
	$gateways[] = 'WC_Gateway_OABiPAY';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_oabipay_add_to_gateways' );
function wc_oabipay_gateway_plugin_links( $links ) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=oabipay_gateway' ) . '">' . __( 'Configure', 'wc-gateway-offline' ) . '</a>'
	);

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_oabipay_gateway_plugin_links' );
add_action( 'plugins_loaded', 'wc_oabipay_gateway_init', 11 );

function wc_oabipay_gateway_init() {

	class WC_Gateway_OABiPAY extends WC_Payment_Gateway {

		public function __construct() {
			$this->id                 = 'oabipay_gateway';
			$this->icon               = apply_filters('woocommerce_offline_icon', '');
			$this->has_fields         = false;
			$this->order_button_text = __( 'Proceed to OAB iPay', 'woocommerce' );
			$this->method_title       = __( 'OAB Payment Gateway', 'wc-gateway-oabipay' );
			$this->method_description = __( 'Allows payments through OAB payment Gateway.', 'wc-gateway-oabipay' );
			$this->init_form_fields();
			$this->init_settings();

			$this->enabled            = $this->get_option( 'enabled' );
			$this->oabTermtitle       = $this->get_option( 'oabTermtitle');
			$this->oabTermdescription         = $this->get_option( 'oabTermdescription' );
			$this->oabTerminstructions = $this->get_option( 'oabTerminstructions' );
			$this->termName = $this->get_option( 'termName' );
			$this->tranType = $this->get_option( 'tranType' );
			$this->tranportalId = $this->get_option( 'tranportalId' );
			$this->termPassword = $this->get_option( 'termPassword' );
			$this->termResKey = $this->get_option( 'termResKey' );

			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );	

			include_once dirname( __FILE__ ) . '/includes/class-wc-gateway-oab-callback.php';
			$callback = new WC_Gateway_OAB_CallBack();
			error_log('Write WC_Gateway_OAB_CallBack trandata '.$_POST['trandata']);
			if(!empty($_REQUEST['trandata'] ) || !(empty( $_REQUEST['error'] ) || empty( $_REQUEST['errorText']))){
				$termResKey = $this->get_option('termResKey');
				error_log('Write WC_Gateway_OAB_CallBack termResKey '.$termResKey);
				$tran_status = $callback->check_response($_POST['trandata'], $termResKey);
				if($tran_status == 'success'){
					$result = apply_filters( 'woocommerce_payment_successful_result', $result, $order_id );
					wp_redirect( $result['redirect'] );
					exit();
				}else{
					wp_redirect( get_permalink( get_option( 'wc_error_page_id' ) ) ); 
					exit();
				}
			}else{
				error_log('Write WC_Gateway_OAB_CallBack trandata '.$_POST['trandata']);
				$this->create_wc_pages();
			}
		}
	
	
		public function init_form_fields() {
	  
			$this->form_fields = array(
		  
				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'wc-gateway-oabipay' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable OAB Payment', 'wc-gateway-oabipay' ),
					'default' => 'yes'
				),
				
				'oabTermtitle' => array(
					'title'       => __( 'Title', 'wc-gateway-oabipay' ),
					'type'        => 'text',
					'description' => __('This controls the title for the payment method the customer sees during payment in OABiPAY.', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'oabTermtitle' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),
				
				'oabTermdescription' => array(
					'title'       => __( 'Description', 'wc-gateway-oabipay' ),
					'type'        => 'text',
					'description' => __( 'This controls the Description for the payment method the customer sees during payment in OABiPAY.', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'oabTermdescription' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),
				'oabTerminstructions' => array(
					'title'       => __( 'Instructions', 'wc-gateway-oabipay' ),
					'type'        => 'text',
					'description' => __( 'Terminal Instruction OABiPAY', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'oabTerminstructions' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),
				'termName' => array(
					'title'       => __( 'Terminal Name', 'wc-gateway-oabipay' ),
					'type'        => 'text',
					'description' => __( 'Payment method Terminal Name that the customer will see on your OABiPAY.', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'termName' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),

				'tranType' => array(
					'title'       => __( 'Payment Type', 'wc-gateway-oabipay' ),
					'type'        => 'select',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-oabipay' ),
					'value'     => __( $this->get_option( 'tranType' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
					'options'	=> array(
						'1' 	=> 'Sand Box',
						'2' 	=> 'Production', 
						),	
				),

				'tranportalId' => array(
					'title'       => __( 'Tranportal Id', 'wc-gateway-oabipay' ),
					'type'        => 'text',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'tranportalId' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),

				'termPassword' => array(
					'title'       => __( 'Tran Password', 'wc-gateway-oabipay' ),
					'type'        => 'password',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'termPassword' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),

				'termResKey' => array(
					'title'       => __( 'Resource Key', 'wc-gateway-oabipay' ),
					'type'        => 'password',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-oabipay' ),
					'default'     => __( $this->get_option( 'termResKey' ), 'wc-gateway-oabipay' ),
					'desc_tip'    => true,
				),
			);
		}
	
	
		public function thankyou_page() {
			error_log('thankyou_page:: '.$this->instructions);
			if ( $this->instructions ) {
				echo wpautop( wptexturize( $this->instructions ) );
			}
		}
	
	
		public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
			if ( $this->instructions && ! $sent_to_admin && $this->id === $order->payment_method && $order->has_status( 'on-hold' ) ) {
				echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
			}
		}
	
	
		public function process_payment( $order_id ) {
			error_log('Write process_payment :: Start ');
			error_log('Tranportal Id :'. $this->get_option('tranportalId'));
			error_log('tranType :'. $this->get_option('tranType'));
			include_once dirname( __FILE__ ) . '/includes/class-wc-gateway-oab-request.php';
			$order = wc_get_order( $order_id );
			$order->update_status( 'on-hold', __( 'Awaiting offline payment', 'wc-gateway-offline' ) );
			$request = new WC_Gateway_OAB_Request();
			$tranType = $this->get_option('tranType');
			$webAddr = '';
			if($tranType == 1){
				$webAddr = 'https://certpayments.oabipay.com/trxns';
			} else if ($tranType == 2) {
				$webAddr = 'https://securepayments.oabipay.com/trxns';
			}
			error_log('webAddr :'. $webAddr);
			$url =	$request->get_payment_args($order, $this->get_option('tranportalId'), $this->get_option('termPassword'), $webAddr, $this->get_option('termResKey'));
			return array(
				'result' 	=> 'success',
				'redirect'	=> $url
			);
		}

		protected function create_wc_pages() {
			error_log('Write create_wc_pages :: Start ');
			$wc_error_page_id = get_option("wc_error_page_id");
			error_log('Write create_wc_pages :: $wc_error_page_id '.$wc_error_page_id);
			if (!$wc_error_page_id) {
				$shopId = get_option('woocommerce_shop_page_id');
				$shop_post = get_post($shopId);
				error_log('Write create_wc_pages :: guid '.$shop_post->guid);	
				$post_id = wp_insert_post(array(
						'post_title' => "Payment Failure",
						'post_type'    => 'page',
						'post_status'  => 'publish',
						'post_content' => $this->get_template($shop_post->guid), 
					)
				);
				error_log('Write create_wc_pages :: $post_id :: '.$post_id);
				if ( ! is_wp_error( $post_id ) && 0 < $post_id ) {
					error_log('Write create_wc_pages :: $is_wp_error :: '.$post_id);
					wp_update_post(
						array(
						'ID'           => $post_id,
						'post_content' => $this->get_template($shop_post->guid),
						)
					);
					update_option( 'wc_error_page_id', $post_id );
					update_post_meta( $post_id, '_wp_page_template', 'payment-failure-page.php' );
				}
			}
  		}

		protected function get_template($guid){
			$template = '<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>OABiPAY Payment Failure</title>
			</head>
			<body onload="">
				<div class="text12" align="center"><div>
			<section class="page-position">
				<div class="container">
					<div class="">
						<div class="">
							<div class="card" style="width: 346px;">
								<div class="payment-content" style="">
									<label><center><font color="red"></font></center><font color="red">The transaction is Failed, try again. </font></label>
									<font color="red">
										<img src="'.plugin_dir_url( __FILE__ ) . "images/error.jpg".'">
										<br/><br/><br/><br/><br/><br/><br/><br/><br/>
										<div><span><a style="color: white; background-color: #237EB5 !important; border-radius: 5px; border: none; display: inline-block; padding: 8px 16px; vertical-align: middle; overflow: hidden; text-decoration: none; color: inherit; text-align: center; cursor: pointer; white-space: nowrap; color: #FFFFFF; margin-bottom: 16px !important;" href="'.$guid.'" class="w3-btn w3-margin-bottom">Go Shop</a></span></div>
										<div><span style="font-size: 8px;color: black;"> Powered by</span></div>
										<div class="container">
											<div class="row">
												<div class="col-12 text-center">
													<p></p> 
													<p><span style="color: #a79f9f;">Copyright © 2021 Oman Arab Bank</span></p>
												</div>
											</div>
										</div>
									</font>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			</body>
			</html>';
			return $template;
		}
	}
}