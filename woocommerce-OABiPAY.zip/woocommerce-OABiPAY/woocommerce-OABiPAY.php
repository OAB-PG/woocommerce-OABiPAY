<?php
/**
 * Plugin Name: WooCommerce OABiPAY
 * Plugin URI: https://www.oman-arabbank.com/
 * Description: A WooCommerce payment gateway plugin to accept online payments through Oman Arab Bank's OAB iPAY service.
 * Version: 1.0.0
 * Author: SundareshKumar KV
 * Author URI: https://www.linkedin.com/in/sundareshkumar-kv-09584860/
 * Requires Plugins: woocommerce
 * WC requires at least: 7.0
 * WC tested up to: 9.9.3
 * WC support for HPOS: yes
 * @package WC-Gateway-OABiPAY
 * @copyright Oman Arab Bank
 *
 * This plugin enables WooCommerce stores to securely integrate with Oman Arab Bank’s iPAY payment system for order checkout.
 */


defined('ABSPATH') || exit;

add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});

add_action('plugins_loaded', function () {
	if (!class_exists('WC_Payment_Gateway')) {
		if (function_exists('wc_get_logger')) {
			$logger = wc_get_logger();
			$logger->error('OABiPAY Init Error: WC_Payment_Gateway class not found. WooCommerce may not be active.', ['source' => 'oabipay']);
		}
		return;
	}

	$logger = wc_get_logger();
	$logger->info('OABiPAY: WC_Payment_Gateway loaded. Initializing plugin...', ['source' => 'oabipay']);

	require_once __DIR__ . '/includes/class-wc-gateway-oabipay.php';

	add_filter('woocommerce_payment_gateways', function ($gateways) use ($logger) {
		$gateways[] = 'WC_Gateway_OABiPAY';
		$logger->info('OABiPAY: Payment gateway registered successfully.', ['source' => 'oabipay']);
		return $gateways;
	});

}, 11);

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
	$plugin_links = [
		'<a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=oabipay_gateway')) . '">' . esc_html__('Configure', 'wc-oabipay') . '</a>',
	];
	return array_merge($plugin_links, $links);
});

add_action('init', 'oabipay_register_callback_handler');

function oabipay_register_callback_handler() {
	if (function_exists('wc_get_logger')) {
		$logger = wc_get_logger();
		$logger->info('OABiPAY: Registering callback handler.', ['source' => 'oabipay']);
	}

	require_once plugin_dir_path(__FILE__) . 'includes/class-wc-gateway-oab-callback.php';

	if (class_exists('WC_Gateway_OAB_CallBack')) {
		new WC_Gateway_OAB_CallBack();
		if (isset($logger)) {
			$logger->info('OABiPAY: Callback handler instantiated.', ['source' => 'oabipay']);
		}
	} else {
		if (isset($logger)) {
			$logger->error('OABiPAY Error: Callback class WC_Gateway_OAB_CallBack not found.', ['source' => 'oabipay']);
		}
	}
}

